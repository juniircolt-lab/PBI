# Validação da entrega Órbita

## Origem e preservação

Base: `Orbita-v2(1).zip`, identificada pelo COMECE-AQUI como a última entrega. Os arquivos extraídos correspondiam à pasta codigo-ultima-entrega do pacote recebido. Os originais foram mantidos intactos; as alterações foram feitas em uma cópia. Nenhum dado pessoal do navegador do usuário foi recebido, acessado ou incluído. Os testes usaram perfis isolados e dados de teste.

As duas versões v2 foram extraídas em pastas separadas e comparadas. Os dois arquivos storage.js eram idênticos; index.html, app.js, app.css e LEIA-ME.txt diferiam. A outra v2 usa tema legado `auto` (18h–7h), controles de filtros diferentes e um calendário que inclui períodos. A base mais recente usa `time` (18h–6h) e eventos nas datas explícitas. Mantivemos o comportamento da base recente, acrescentando compatibilidade com a preferência `auto` em backups antigos. Não mesclamos silenciosamente a lógica de períodos da outra v2.

## Correções

- Inicialização: a barra de filtros era acessada antes de existir. O erro interrompia a renderização; a preparação agora acontece antes da primeira renderização.
- Filtros: valores em edição ficam separados dos filtros aplicados. Alterar o painel não filtra antecipadamente. Aplicar, limpar, salvar e reabrir filtros foram exercitados.
- Tabela: salvar atualiza a tabela, os contadores e a lista de projetos. Linhas que deixam de satisfazer o filtro são retiradas. Enter, Tab, Shift+Tab, blur e Esc têm caminhos consistentes. Validação ocorre antes de alterar o registro, inclusive quando o novo status cria datas automáticas.
- Datas: o formulário não alterna mais o tipo do campo durante o envio, evitando perder datas após erro. Horários e o valor ISO original são preservados ao salvar sem mudança. Edição de data na tabela conserva a hora existente. Calendário interpreta timestamps no fuso local, em vez de recortar a data UTC.
- Calendário: avançar/voltar parte do primeiro dia do mês, evitando pular fevereiro quando aberto no dia 31.
- Cartões: comparação cronológica usa instantes reais, permitindo misturar timestamps com fuso e datas locais. Movimentos inválidos revertem os valores.
- Prévia: usa a mesma paleta do aplicativo, inicializa ao abrir, reflete o tema e as cores restauradas/importadas e contém exemplos de menu, áreas, status, atraso e gráfico.
- Backup: valida preferências, filtros e dias de prazo impossíveis antes de substituir os dados.
- Persistência: falha no armazenamento do navegador não é anunciada como sucesso. Erros de pasta são informados sem descartar a cópia local já salva. Quando a conexão carrega um arquivo mas falha ao escrever, a interface mantém os dados carregados e informa a desconexão.

## Resultado final

24 grupos de testes passaram: 13 em validacao.cjs e 11 em casos-adicionais.cjs. Os resultados detalhados estão nos dois arquivos resultado-*.txt. Nenhuma exceção de JavaScript foi capturada nas execuções finais.

Cobertura: inicialização; criar/editar/excluir; datas à meia-noite e hora customizada; cronologia inválida; Enter/Tab/Shift+Tab/Esc; filtros pendentes, aplicados, limpos e salvos; estatísticas após edição; arraste em ambos os sentidos e reversão; calendário com início, conclusão, prazo, datas coincidentes, expansor, ausência de data, UTC perto da meia-noite e navegação do dia 31; tema do sistema e por horário; prévia, cancelar, aplicar, restaurar e importar/exportar estilo; exportação completa com filtros e importação inválida; importação válida e recarga; dashboard com duração corrida e atrasos; captura desktop e viewport estreito; pasta simulada e falha de quota do localStorage.

## Limites reais

- Navegador: Chromium headless do sistema, via Playwright. Fuso America/Sao_Paulo; locale pt-BR. Aplicativo acessado em servidor HTTP local.
- A política do navegador bloqueou os esquemas data: e file: com ERR_BLOCKED_BY_ADMINISTRATOR. HTTP local abriu e foi usado para os testes funcionais. A execução file:// por duplo clique não foi validada.
- O seletor nativo de pasta não foi operado. Os testes de pasta substituem showDirectoryPicker por uma implementação simulada; não verificam permissões reais, sistema de arquivos de usuário ou diferenças entre navegadores.
- Viewport estreito não equivale a teste em celular físico. Não executado em Safari, Firefox ou Edge.
- Dados pessoais do usuário não foram fornecidos. Não foi verificada a migração de um backup pessoal real; os testes preservaram a estrutura, os IDs, notas, tags, preferências e atividades do backup sintético.
- Sem integração Google Drive e sem publicação externa.

## Reproduzir tecnicamente

Requisitos: Node.js, Python 3, Chromium e pacote npm playwright. Não são dependências do aplicativo estático.

1. Na pasta Orbita, execute `python -m http.server 8766 --bind 127.0.0.1`.
2. Em um diretório temporário, instale Playwright: `npm install --prefix /tmp/orbita-tools --cache /tmp/orbita-npm-cache playwright`.
3. Na pasta Orbita, execute `NODE_PATH=/tmp/orbita-tools/node_modules node validacao/validacao.cjs` e `NODE_PATH=/tmp/orbita-tools/node_modules node validacao/casos-adicionais.cjs`.
4. Os scripts usam /usr/bin/chromium. Se necessário, altere executablePath para o Chromium instalado. ORBITA_URL permite informar outro endereço HTTP. As capturas são gravadas na pasta dos testes.

As suítes foram executadas antes do empacotamento. A suíte principal também foi executada a partir da cópia extraída do ZIP final, conforme o resultado da verificação de entrega.
